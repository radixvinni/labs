//---------------------------------------------------------------------------

#include <vcl.h>
#include <sys\timeb.h>

#pragma hdrstop

#include "Unit1.h"

//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TForm1 *Form1;

void BitOperation(int n);
void CharOperation(int n);

int Nk=100000;

//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------

void __fastcall TForm1::Button1Click(TObject *Sender)
{
      // ������ ��������
  int n=1000;    
    BitOperation(n);

    ShowMessage("�����");
}
//---------------------------------------------------------------------------
void BitOperation(int n)
{
  timeb tm1,tm2;
  int i,j,k;
  unsigned int a=0x77777777,b=0xCCCCEEEE;
  unsigned int mask=0x80000000;
  unsigned int *m1=new unsigned int[n];
  unsigned int *m2=new unsigned int[n];
  unsigned int *m3=new unsigned int[n];
  for(i=0;i<n;i++) m1[i]=a;
  for(i=0;i<n;i++) m2[i]=b;
  ftime(&tm1);
  for(k=0;k<Nk;k++)
    for(i=0;i<n;i++) m3[i]=m1[i] & m2[i];
  ftime(&tm2);
  Form1->Edit1->Text=AnsiString(tm1.time);
  Form1->Edit2->Text=AnsiString(tm1.millitm);
  Form1->Edit3->Text=AnsiString(tm2.time);
  Form1->Edit4->Text=AnsiString(tm2.millitm);
  for(j=0;j<32;j++)
    if(m3[0] & (mask>>j))
      Form1->StringGrid1->Cells[j][0]=AnsiString('1');
    else
      Form1->StringGrid1->Cells[j][0]=AnsiString('0');

}

void CharOperation(int n)
{
  timeb tm1,tm2;
  int i,j,k;
  char a='1',b='0';
  char *m1=new char[n];
  char *m2=new char[n];
  char *m3=new char[n];
  for(i=0;i<n;i++) m1[i]=a;
  for(i=0;i<n;i++) m2[i]=b;
  ftime(&tm1);
  for(k=0;k<Nk;k++)
    for(i=0;i<n;i++)
      if(m1[i]=='1' && m2[i]=='1') m3[i]='1';
        else m3[i]='0';

  ftime(&tm2);
  Form1->Edit1->Text=AnsiString(tm1.time);
  Form1->Edit2->Text=AnsiString(tm1.millitm);
  Form1->Edit3->Text=AnsiString(tm2.time);
  Form1->Edit4->Text=AnsiString(tm2.millitm);
  for(i=0;i<64;i++)
    Form1->StringGrid1->Cells[i][0]=AnsiString(m3[i]);


}
void __fastcall TForm1::Button2Click(TObject *Sender)
{
  int n=32000;
  CharOperation(n);
  ShowMessage("�����");
}
//---------------------------------------------------------------------------

